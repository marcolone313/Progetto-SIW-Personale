package it.uniroma3.siw.start;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import it.uniroma3.siw.model.Artista;
import it.uniroma3.siw.model.Collezione;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Curatore;
import it.uniroma3.siw.model.Opera;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.service.ArtistaService;
import it.uniroma3.siw.service.CollezioneService;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.CuratoreService;
import it.uniroma3.siw.service.OperaService;
import it.uniroma3.siw.service.UserService;

@Component
public class Inizializzazione implements ApplicationListener<ContextRefreshedEvent> {
	@Autowired
	private UserService userService;
	
	@Autowired
	private CredentialsService credentialService;
	
	@Autowired
	private CuratoreService curatoreService;
	
	@Autowired
	private CollezioneService collezioneService;
	
	@Autowired
	private ArtistaService artistaService;
	
	@Autowired
	private OperaService operaService;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		User user1 = new User();
		user1.setNome("user1");
		user1.setCognome("user1");
		userService.saveUser(user1);
		
		Credentials credentials1 = new Credentials();
		credentials1.setUsername("admin");
		credentials1.setRole("ADMIN");
		credentials1.setPassword("admin");
		credentials1.setUser(user1);
		credentialService.saveCredentials2(credentials1);
		
		User user2 = new User();
		user2.setNome("user2");
		user2.setCognome("user2");
		userService.saveUser(user2);
		
		Credentials credentials2 = new Credentials();
		credentials2.setUsername("user");
		credentials2.setPassword("user");
		credentials2.setRole("DEFAULT");
		credentials2.setUser(user2);
		credentialService.saveCredentials2(credentials2);
		
		Curatore curatore1=new Curatore();
		curatore1.setNome("Marco");
		curatore1.setCognome("Giorgi");
		curatore1.setDataDiNascita(LocalDate.of(1975, 10, 20));
		curatore1.setLuogoDiNascita("Roma");
		curatore1.setEmail("m.giorgi@oscinnovation.com");
		curatore1.setNumeroDiTelefono(331741155);
		curatore1.setMatricola(118);
		curatoreService.inserisci(curatore1);
		
		Collezione collezione1 = new Collezione();
		collezione1.setCuratore(curatore1);
		collezione1.setNome("Esposizione Scultorea Della Grecia Ellenistica ");
		collezione1.setDescrizione("Dall'apertura del Museo Scultoreo Di Roma sarà possibile visitare l'esposizione Scultorea dell'antica Grecia Ellenistica, organizzata da Marco Giorgi. \r\n");
		collezioneService.inserisci(collezione1);
		
		Artista artista1 = new Artista();
		artista1.setNome("Alessandro");
		artista1.setCognome("Di Antiochia");
		artista1.setDataDiNascita("150A.c.");
		artista1.setLuogoDiNascita("Antiochia Sul Meandro");
		artista1.setDataDiMorte("100A.c.");
		artista1.setLuogoDiMorte("Grecia");
		artista1.setNazionalita("Greca");
		artista1.setDescrizione("Attivo nel I secolo a.C., è conosciuto soprattutto per essere l'autore della Venere di Milo, opera greca tra le più famose alta circa 2 metri che ha perso le braccia e il piedistallo originale, rinvenuta nell'isola di Milo nel 1820 e attualmente conservata al Louvre di Parigi.\n"
				+ "\n"
				+ "La sua identità ci è nota tramite le antiche iscrizioni che recano la sua firma, tra le quali il piedistallo rinvenuto insieme alla Venere, che è stato rimosso e perso a causa delle politiche e dell'orgoglio nazionale del Louvre negli anni 1820.[la frase andrebbe chiarita o rimossa] L'iscrizione e lo stile della scrittura mettono in dubbio il fatto che la statua sia un originale del maestro scultore Prassitele.[non si capisce, la frase è ambigua]\n"
				+ "\n"
				+ "Sembra che Alessandro sia stato un artista viaggiatore, chiamato a lavorare per differenti committenti. Un'iscrizione rinvenuta nell'antica città di Tespie risalente all'80 d.C., lo ricorda come vincitore di una gara di composizione e canto; conosciamo inoltre, sempre grazie alle iscrizioni rinvenute, il nome di suo padre, che si chiamava Menide. ");
		artistaService.inserisci(artista1);
		
		Opera opera1 = new Opera();
		opera1.setArtista(artista1);
		opera1.setTitolo("Venere Di Milo");
		opera1.setAnno(100);
		opera1.setCollezioni(collezione1);
		opera1.setDescrizione("L’Afrodite di Milo, meglio conosciuta come Venere di Milo, è una delle più celebri statue greche.\n"
				+ "\n"
				+ "Si tratta di una scultura di marmo pario alta 202 cm priva delle braccia e del basamento originale ed è conservata al Museo del Louvre di Parigi.\n"
				+ "\n"
				+ "Sulla base di un'iscrizione riportata sul basamento andato perduto si ritiene che si tratti di un'opera di Alessandro di Antiochia anche se in passato alcuni la attribuirono erroneamente a Prassitele. ");
		opera1.setFile("https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Front_views_of_the_Venus_de_Milo.jpg/800px-Front_views_of_the_Venus_de_Milo.jpg");
		operaService.inserisci(opera1);
	}
}
