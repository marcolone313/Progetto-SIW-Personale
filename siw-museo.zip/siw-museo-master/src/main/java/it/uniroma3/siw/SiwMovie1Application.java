package it.uniroma3.siw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiwMovie1Application {

	public static void main(String[] args) {
		SpringApplication.run(SiwMovie1Application.class, args);
	}

}
